Open-Source Web Application Firewall Implementation Using ModSecurity Engine
A Performance and Security Evaluation Framework

Author: Md Anisur Rahman Chowdhury (Gannon University)
Co-author: Samuel Tweneboah-Koduah, Ph.D. (Campbellsville University)

HOW TO COMPILE
---------------
This paper is self-contained (all diagrams are inline TikZ/pgfplots; no
external image files are required).

Requires a TeX distribution with IEEEtran, tikz, and pgfplots (TeX Live
2020+ or MiKTeX with those packages installed).

    pdflatex main.tex
    pdflatex main.tex   (run twice to resolve references)

Output: main.pdf

LICENSE
-------
Released for academic/educational use. Please cite the paper if you use
or adapt this work.
