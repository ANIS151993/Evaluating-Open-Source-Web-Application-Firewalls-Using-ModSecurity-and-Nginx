# Open-Source Web Application Firewall Implementation Using ModSecurity Engine

**A Performance and Security Evaluation Framework**

Md Anisur Rahman Chowdhury¹ · Samuel Tweneboah-Koduah, Ph.D.¹
Dept. of Computer and Information Science, Gannon University · Campbellsville University

## What's in this project

```
WAF-ModSecurity-Paper/
├── main.tex          # IEEE-format paper source
├── references.bib    # BibTeX bibliography (IEEEtran style)
├── figures/           # All 9 figures referenced by the paper
└── README.md          # This file
```

This is a complete, self-contained Overleaf/LaTeX project — every figure the
paper references ships in `figures/`, and the bibliography is a proper
`.bib` file rather than an inline list, so you can add/edit references the
normal BibTeX way.

## How to compile

### Option A: Overleaf

1. Create a new project → **Upload Project** → select this whole folder
   (or a zip of it).
2. Overleaf auto-detects `main.tex` as the root document.
3. Overleaf runs `pdflatex → bibtex → pdflatex → pdflatex` automatically on
   first compile (its default recipe). If it doesn't pick up the
   bibliography on the first try, click **Recompile** once more.

### Option B: Local TeX Live / MiKTeX

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

**Requirements:** `IEEEtran` class + `IEEEtran.bst` (on Debian/Ubuntu:
`sudo apt install texlive-publishers`; on most other distributions and
MiKTeX/Overleaf this ships by default), plus the standard `graphicx`,
`amsmath`, `booktabs`, `multirow`, `tikz`, and `pgfplots` packages (only the
system-architecture diagram, Fig. 5, still uses TikZ — every other figure is
a pre-rendered PNG in `figures/`).

## License

The code/build artifacts referenced by this paper are released under the
MIT license (see the project's GitHub repository). The paper text and
figures remain the copyright of the authors.
